import {Injectable} from '@angular/core';
import {Http, Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';

@Injectable()
export class ImageService{
   constructor(private http:Http) { }
  // Uses http.get() to load a single JSON file
getImg() {

     return this.http.get('app/src/data1.json').map((res:Response) => res.json());
  }
}
