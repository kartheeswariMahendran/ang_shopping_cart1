import { Component } from '@angular/core';
import { GetName } from './getName.service';
 // import {AppServices} from './jsonget.service';
}
import { FormGroup, FormBuilder } from '@angular/forms';
// import {JsonComponent} from './jsonCom.component';
@Component({
  selector: 'page',
  template: `<h3>My Shopping Items</h3>
  <section>
  <button (click)=login() *ngIf="LoginButton">Login</button>
  <button (click)=logout() *ngIf="LogoutButton">Logout</button>
  <div *ngIf="loginClick">
        <label>First Name:</label>
        <!-- Since we are working with template driven forms, we can use the ngModel directive to capture the values of our forms. One thing to note if you are coming from Angular 1.x. Using ngModel as shown below creates a one-way data binding, so once we hit submit the data is only sent to the controller. If we wanted to use two-way data binding, we would have to wrap the ngModel in [()] and assign an attribute to it. Also the name of the field corresponds to the name attribute so our first input will be firstName. -->
        <input type="text" class="form-control" placeholder="John" name="firstName" [(ngModel)]="firstName"required><br>
        <label>Last Name</label>
        <input type="text" class="form-control" placeholder="Doe" name="lastName" [(ngModel)]="lastName" required>
        <button  (click)=submitLogin(firstName,lastName)>Submit</button>
  </div>

  <div *ngIf="afterLogin">
  welcome {{value}}
  </div>

  <button (click)=cart()>cart</button>
  <div *ngIf="cartItems">
  <strong>cart Items Saved!</strong> 
  </div>
  </section>
  <shopimg></shopimg>
  
  
 `,
 styleUrls: ['app/src/pagestyle.component.css']
})
export class PageComponent { 
fullImagePath:any;
loginClick = false;
LoginButton=true;
LogoutButton=false;
afterLogin=false;
cartItems=false;
value:any;
constructor(public getName:GetName){}
login() {
    this.LoginButton=false;
    this.loginClick = !this.loginClick;
    this.LogoutButton=true;
    
    
  }
  logout() {
    this.LoginButton=true;
    this.LogoutButton=false;
    this.afterLogin=false;
  }
  
 cart()
 {
 this.cartItems = !this.cartItems;
 }

 submitLogin(firstName:any,lastName:any)
 {
  
   this.value=firstName;
   this.getName.setName(this.value);
   console.log(this.getName.getName());
   this.afterLogin=true;
   this.loginClick=false;

 }
  }