import { Component,Inject } from '@angular/core';
import {Http, Response} from '@angular/http';
import {FullImageComponent} from './fullImage.component';
import {Router,Params} from '@angular/router';
 import {ImageService} from './imgService.service';
   import {FullImageComponent} from './fullImage.component';
   import { ROUTER_DIRECTIVES } from '@angular/router';
   import { GetName } from './getName.service';
   import {CartComponent} from './cart.component';


@Component({
  selector: 'shopimg',
  template: `
  <div class="cart-img"><img src="app/src/images/cart.jpg" class="cart" (click)="cartItems()"/><span class="count">{{count}}</span></div>
  <table class='wrapper1'>
  <tr *ngFor="let keys of jsonKey; let i = index" (click)="fun(i)">
    <td>{{keys}}</td>
   
  </tr>
  </table>
  <div class="particularItem" *ngFor="let t of temp1[ind]">
    <img src="{{t.img}}"/>
     <div >{{t.name}}</div>
     <div>{{t.price}}</div> 
    <button (click)="cart1(t)">Add to Cart</button>
    <button (click)="selectedImage(values)">buy now</button>
    </div>
  <!-- this is the new syntax for ng-repeat -->
  <div class="carousel">{{jsonKeySlide}}
   <ul class="slides">
    <li *ngFor="let i of jsonValuesSlide[0]">
          <img src="{{i}}" />     
    </li>
    </ul>
    </div>
    <div>
 <div >


<table class='wrapper1'>
  <tr *ngFor="let keys of jsonKey; let i = index">
    <td>{{keys}}</td>
    <td *ngFor="let t of temp1[i]">
    <img src="{{t.img}}"/>
     <div >{{t.name}}</div>
     <div>{{t.price}}</div> 
    <button (click)="cart1(t)">Add to Cart</button>
    <button (click)="selectedImage(values)">buy now</button>
    </td>
</tr>
</table>
    </div>
    
   
  
   `,
 styleUrls: ['app/src/imagestyle.component.css']

})

export class ImageComponent {
   jsonData:any;
   templength:any
   add:any;
   ind:any;
   a:any;
   b:any;
   jsonKeySlide:any=[];
   jsonValuesSlide:any=[];
    jsonKey:any=[];
     jsonValues:any=[];
       tempJsonValues:any=[];
        d4:any=[];
        slideValues:any=[];
       itemNos:any=[];
       c:any=[];
       itemCount:any=0;
       temp:any=[];
       temp1:any=[];;
count:any=0;

constructor(@Inject('aservice') public services1:any,public router:Router,public getName:GetName)
 {
this.a=this.services1.getImg();
this.c=localStorage.getItem("cartItems")?JSON.parse(localStorage.getItem("cartItems")):[];
console.log(this.c);
this.count=localStorage.getItem("count")?JSON.parse(localStorage.getItem("count")):[];

//this.itemCount=JSON.parse(localStorage.getItem('count'));
/*this.locCart=JSON.parse(localStorage.getItem('cartItems'));
this.getName.setCart(this.locCart);*/
 }
 
 ngOnInit()
 {
     this.a=this.services1.getImg();
     this.c=localStorage.getItem("cartItems")?JSON.parse(localStorage.getItem("cartItems")):[];
     console.log(this.c);
    this.count=localStorage.getItem("count")?JSON.parse(localStorage.getItem("count")):[];
     this.a.subscribe(data => { this.jsonData = data; 
     this.jsonKey=Object.keys(this.jsonData[1]);
     this.jsonValues=Object.values(this.jsonData[1]);
     this.jsonKeySlide=Object.keys(this.jsonData[0]);
     this.jsonValuesSlide=Object.values(this.jsonData[0]);
     this.jsonKey.forEach((key:any,index:any) => {
     this.a[index]=Object.values(this.jsonValues[index]);
     this.temp=[];
     console.log( this.jsonKey[index]);
     this.a[index].forEach((key:any,i:any) => {
     this.temp.push(this.a[index][i]);
     }); 
     this.temp1[index]=this.temp;
     this.templength=this.temp.length;
  });
    
   })
   }
   cart1(a)
{
  this.count1=0;
  
     console.log(this.c.length);
      if(this.c.length>0)
      {
      for(let i=0;i<this.c.length;i++)
        {
          console.log("this.c[i]");
          console.log(this.c[i]);
          console.log("a");
          console.log(a);
          if(a===this.c[i])
          {
            console.log("already");
            alert("already in cart");
            break;
          }
        else{
            console.log("not already");
          this.count1++;
        }
      }
      if(this.count1==this.c.length)
      {
        this.c.push(a);
        this.count++;
        console.log("this.count"+this.count);
      localStorage.setItem('count',JSON.stringify(this.count));      
      JSON.parse(localStorage.getItem('count'));
         localStorage.setItem('cartItems',JSON.stringify(this.c));      
      this.locCart=JSON.parse(localStorage.getItem('cartItems'));
      this.getName.setCart(this.locCart);

      }
    }
      else
      {
      this.c.push(a);
      this.count++;
      console.log("this.c"+this.c);
      console.log("this.count"+this.count);
      localStorage.setItem('count',JSON.stringify(this.count));      
      JSON.parse(localStorage.getItem('count'));
         localStorage.setItem('cartItems',JSON.stringify(this.c));      
      this.locCart=JSON.parse(localStorage.getItem('cartItems'));
      this.getName.setCart(this.locCart);

    }

   

      
  
}




cartItems()
{
   this.router.navigate(['/cart']);
}
selectedImage(img:any){
    console.log(img);
    localStorage.setItem('selectImage',JSON.stringify(img));      
    this.router.navigate(['/imageDetails']);
        //this.router.navigate(['/fullImage',{ queryParams: "{"page""+img+""} ]);
        
     }
     fun(i)
     {
 this.ind=i;
console.log(i);
     }

}
// { queryParams: "{"page":"+img+"}" }

 // console.log(this.jsonValues[0][0]);
 //      this.innerKey=Object.keys(this.jsonValues[0][0]);
 //      this.innerValues=Object.values(this.jsonValues[0][0]);
 //      console.log("this.innerKey"+this.innerKey);
 //      console.log("this.innerValues"+this.innerValues[1]);
 //      this.jsonKeySlide=Object.keys(this.jsonData[0]);
 //      this.jsonValuesSlide=Object.values(this.jsonData[0]);
 //      //
 //      this.jsonValues[0].forEach((key:any,index:any) => {
 //        console.log(this.jsonValues[index]);
 //        });
      //