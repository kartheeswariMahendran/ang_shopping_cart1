import {Injectable} from '@angular/core';

@Injectable()
export class GetName{
	val:any;
	val1:any=[];
  val2:any=[];
   constructor() { }
  setName(v)
  {
	this.val=v;
  }
	getName() {
   return this.val;
  }
  setCart(v1)
  {
	this.val1=v1;
  console.log("this.val1"+this.val1)
  }
	getCart() {
  console.log("get this.val1"+this.val1)

     return this.val1;
  }
   setNoItems(v2)
  {
  this.val2=v2;
  console.log("this.val2"+this.val2);
  }
  getNoItems() {
  console.log("get this.val2"+this.val2);
     return this.val2;
  }
}
