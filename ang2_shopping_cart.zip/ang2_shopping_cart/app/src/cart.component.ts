import { OnInit, OnDestroy,Component } from "@angular/core";
import { ActivatedRoute, Router,Params } from '@angular/router';
import { pageComponent } from './page.component';
import { GetName } from './getName.service';
import { ImageDetailsComponent} from './imageDetails.component'
@Component({
   selector: 'cart',
  template: `<h1>Selected Item</h1>
  <p>Welcome {{name}}</p>
<table>

<tr><td>Item no</td><td>selected Item</td><td>Price</td><td>number of items</td>
<td>Total Price</td>
<td>add or remove</td></tr>
<tr  *ngFor="let im of addCart">
<td>1</td>
<td>
<img src={{im.img}} /> 
 <p >{{im.name}}</p>
</td>
<td>{{im.price}}</td>
<td><input type="number" [(ngModel)]="num" width="10px" height="10px"/></td>
<td>{{total}}</td>
<td (click)="additem()">ADD </td>
</tr>
</table>
<div *ngIf="add" class="item-added">Item Added Successfully</div>
  `,
  styleUrls: ['app/src/selecteditem.component.css']

})


export class CartComponent{
 num:any=1;
 total:any;
	addCart:any;
	add:any=false;
  noItems:any;
constructor(public getName:GetName) {	
  
this.name=this.getName.getName();
 this.addCart=this.getName.getCart();
 this.noItems=this.getName.getNoItems();
console.log(this.addCart);    
this.total=this.num;
    }
    additem():any
    {
this.add=true;
    }
}