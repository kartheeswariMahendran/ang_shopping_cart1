import { OnInit, OnDestroy,Component } from "@angular/core";
import { ActivatedRoute, Router,Params } from '@angular/router';
import { pageComponent } from './page.component';
import { GetName } from './getName.service';

@Component({
   selector: 'page2',
  template: `<h1>Selected Item</h1>
<div>user:{{addName}}</div>
<p>
<img src="{{userId}}" />     
</p>
<button (click)="additem()">ADD ITEM</button>
<div *ngIf="add" class="item-added">Item Added Successfully</div>
  `,
  styleUrls: ['app/src/selecteditem.component.css']

})


export class FullImageComponent implements OnInit, OnDestroy {
  addName:any;
	userId:any;
	add:any=false;
constructor(private activatedRoute: ActivatedRoute,private router: Router,public getName:GetName) {
	this.activatedRoute.params.subscribe((params: Params) => {
        this.userId = params['page'];
        console.log(this.userId);
      });
}
     ngOnInit() {
    this.addName=this.getName.getName();
  console.log(this.userId);
  }
   ngOnDestroy() {
    this.sub.unsubscribe();
  }
    additem():any
    {
this.add=true;
    }
}