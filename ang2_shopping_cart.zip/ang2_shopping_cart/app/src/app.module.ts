import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
 import { Routes, RouterModule } from '@angular/router';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpModule } from '@angular/http';
import {AppComponent} from './app.component';
  import {PageComponent} from './page.component';
   
  import {ImageComponent} from './imageCom.component';
  import { ImageService } from './imgService.service';
import { GetName } from './getName.service';
import { ImageDetailsComponent} from './imageDetails.component'
import {CartComponent} from './cart.component';

  import 'rxjs/add/operator/map';

 

@NgModule({
  imports 		: [ BrowserModule,
  FormsModule,ReactiveFormsModule,HttpModule,RouterModule.forRoot([
                  {path: '',component: PageComponent }, 
                  {path: 'imageDetails',component: ImageDetailsComponent}
                  {path: 'cart',component: CartComponent}])
  				

  				  ],
  declarations 	: [ AppComponent,PageComponent,ImageComponent,ImageDetailsComponent,CartComponent],
  bootstrap 	: [ AppComponent ],
  // providers: [AppServices] 
  providers : [{ provide: "aservice", useClass: ImageService},GetName]


})

export class AppModule { 

}
