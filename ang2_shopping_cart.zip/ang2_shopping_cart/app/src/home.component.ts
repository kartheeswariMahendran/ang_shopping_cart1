import { Component } from "@angular/core";
import{ PageComponent } from './page.component';
 import {ImageService} from './imgService.service';
 import {ImageComponent} from './ImageCom.component';


@Component({
   selector: 'my-app',
  template: `<h1>Shopping Cart</h1>
 <page></page>
  <router-outlet></router-outlet>
  `,
  styleUrls: ['app/src/app.component.css']

})


export class AppComponent {
	 

}