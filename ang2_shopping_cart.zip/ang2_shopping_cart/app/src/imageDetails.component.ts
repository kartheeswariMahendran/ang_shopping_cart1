import { OnInit, OnDestroy,Component } from "@angular/core";
import { ActivatedRoute, Router,Params } from '@angular/router';
import { pageComponent } from './page.component';
import { GetName } from './getName.service';
import { ImageDetailsComponent} from './imageDetails.component'
@Component({
   selector: 'page2',
  template: `<h1>Selected Item</h1>

<p>
<img src={{userId}} />     
</p>
<button (click)="additem()">ADD ITEM</button>
<div *ngIf="add" class="item-added">Item Added Successfully</div>
  `,
  styleUrls: ['app/src/selecteditem.component.css']

})


export class ImageDetailsComponent{
  // addName:any;
	userId:any;
	add:any=false;
constructor(public getName:GetName) {	
this.userId=JSON.parse(localStorage.getItem('selectImage'));
console.log(this.userId);    
    }
// }
//      ngOnInit() {
//     this.addName=this.getName.getName();
//   console.log(this.userId);
//   }
   
    additem():any
    {
this.add=true;
    }
}